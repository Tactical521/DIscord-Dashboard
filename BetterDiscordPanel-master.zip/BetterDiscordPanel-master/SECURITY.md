# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.7.x   | :white_check_mark: |
| < 2.0   | :x:                |

## Reporting a Vulnerability

Please email <a href="mailto:sanjaysunil@protonmail.com"> sanjaysunil@protonmail.com </a>to report a vulnerability.
